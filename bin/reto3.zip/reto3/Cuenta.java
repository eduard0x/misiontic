package reto3;

public class Cuenta {
	String numero_tarjeta_credito;
	double cantidad_dinero;
	public Cuenta(String numero_tarjeta_credito, double cantidad_dinero) {
		super();
		this.numero_tarjeta_credito = numero_tarjeta_credito;
		this.cantidad_dinero = cantidad_dinero;
	}
	
	
}
