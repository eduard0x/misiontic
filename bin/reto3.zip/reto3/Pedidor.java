package reto3;

public class Pedidor {
	
	Pedido[] lista_pedidos = new Pedido[1];
	public Pedidor() {
		
	}
	
	public void cobrar() {
		
	}
	
	public void ordenar_distribucion() {
		
	}
	
	public void confirmar_pedidos() {
		
	}
	
}
